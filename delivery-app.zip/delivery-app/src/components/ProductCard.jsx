import { memo, useState } from 'react'
import { money } from '../utils'

export function Img({ src, alt, emoji = '🍽️' }) {
  const [failed, setFailed] = useState(!src)
  if (failed) return <div className="img-fallback" aria-hidden="true">{emoji}</div>
  return <img src={src} alt={alt} loading="lazy" decoding="async" onError={() => setFailed(true)} />
}

function ProductCard({ item, qty, onAdd, onRemove, onOpen }) {
  return (
    <article className="card">
      <button className="card-main" onClick={() => onOpen(item)} aria-label={`Ver detalhes de ${item.name}`}>
        <div className="card-text">
          {item.badge && <span className="badge">{item.badge}</span>}
          <h3>{item.name}</h3>
          <p className="desc">{item.description}</p>
          <div className="price-row">
            <strong className="price">{money(item.price)}</strong>
            {item.oldPrice && <s className="old">{money(item.oldPrice)}</s>}
          </div>
        </div>
        <div className="card-img">
          <Img src={item.image} alt={item.name} />
        </div>
      </button>

      <div className="card-action">
        {qty > 0 ? (
          <div className="stepper" role="group" aria-label={`Quantidade de ${item.name}`}>
            <button onClick={() => onRemove(item.id)} aria-label="Remover um">−</button>
            <span>{qty}</span>
            <button onClick={() => onAdd(item)} aria-label="Adicionar mais um">+</button>
          </div>
        ) : (
          <button className="add-btn" onClick={() => onAdd(item)} aria-label={`Adicionar ${item.name}`}>
            +
          </button>
        )}
      </div>
    </article>
  )
}

export default memo(ProductCard)
