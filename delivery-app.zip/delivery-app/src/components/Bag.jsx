import { useEffect, useMemo, useRef, useState } from 'react'
import { brand } from '../config'
import { categories } from '../menu'
import { Img } from './ProductCard'
import { buildWhatsAppUrl, load, maskPhone, money, onlyDigits, save } from '../utils'

const CUSTOMER_KEY = 'delivery:customer:v1'
const allItems = categories.flatMap((c) => c.items)

export default function Bag({ cart, onClose, onAddItem }) {
  const { lines, dispatch, subtotal } = cart
  const saved = load(CUSTOMER_KEY, {})

  const [mode, setMode] = useState(saved.mode === 'pickup' && brand.pickupEnabled ? 'pickup' : 'delivery')
  const [customer, setCustomer] = useState({
    name: saved.name || '',
    phone: saved.phone || '',
    address: saved.address || '',
    complement: saved.complement || '',
  })
  const [paymentId, setPaymentId] = useState(saved.paymentId || brand.payments[0].id)
  const [change, setChange] = useState('')
  const [errors, setErrors] = useState({})
  const [sent, setSent] = useState(false)
  const [copied, setCopied] = useState(false)
  const refs = { name: useRef(), phone: useRef(), address: useRef() }

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [onClose])

  const fee = mode === 'pickup' ? 0 : brand.freeDeliveryFrom > 0 && subtotal >= brand.freeDeliveryFrom ? 0 : brand.deliveryFee
  const total = subtotal + fee
  const payment = brand.payments.find((p) => p.id === paymentId) || brand.payments[0]
  const belowMin = brand.minOrder > 0 && subtotal < brand.minOrder
  const freeLeft = brand.freeDeliveryFrom - subtotal

  const upsell = useMemo(() => {
    const inCart = new Set(lines.map((l) => l.id))
    return allItems.filter((i) => i.popular && !inCart.has(i.id)).slice(0, 4)
  }, [lines])

  const set = (k) => (e) => {
    const v = k === 'phone' ? maskPhone(e.target.value) : e.target.value
    setCustomer((c) => ({ ...c, [k]: v }))
    if (errors[k]) setErrors((er) => ({ ...er, [k]: undefined }))
  }

  const validate = () => {
    const er = {}
    if (customer.name.trim().length < 2) er.name = 'Informe seu nome'
    if (onlyDigits(customer.phone).length < 10) er.phone = 'Informe um WhatsApp válido'
    if (mode === 'delivery' && customer.address.trim().length < 5) er.address = 'Informe rua e número'
    setErrors(er)
    const first = ['name', 'phone', 'address'].find((k) => er[k])
    if (first) refs[first].current?.focus()
    return !first
  }

  const submit = () => {
    if (belowMin || !validate()) return
    save(CUSTOMER_KEY, { ...customer, mode, paymentId })
    const url = buildWhatsAppUrl({
      lines,
      mode,
      customer,
      payment,
      change: change.trim(),
      subtotal,
      fee,
      total,
    })
    window.open(url, '_blank', 'noopener')
    setSent(true)
  }

  const copyPix = async () => {
    try {
      await navigator.clipboard.writeText(brand.pixKey)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      /* ignore */
    }
  }

  if (sent) {
    return (
      <div className="overlay" onClick={onClose}>
        <div className="sheet sheet-done" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
          <div className="done-icon">✅</div>
          <h2>Pedido enviado!</h2>
          <p className="desc full">
            Seu pedido foi aberto no WhatsApp. Basta tocar em <b>enviar</b> na conversa para confirmar com a
            gente. Previsão: {mode === 'delivery' ? brand.deliveryTime : brand.pickupTime}.
          </p>
          <button
            className="btn-primary"
            onClick={() => {
              dispatch({ type: 'clear' })
              onClose()
            }}
          >
            Fazer novo pedido
          </button>
          <button className="btn-link" onClick={() => setSent(false)}>
            Voltar à sacola (o WhatsApp não abriu?)
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet bag" role="dialog" aria-modal="true" aria-label="Sacola" onClick={(e) => e.stopPropagation()}>
        <div className="bag-head">
          <h2>Sua sacola</h2>
          <button className="close inline" onClick={onClose} aria-label="Fechar sacola">✕</button>
        </div>

        <div className="bag-scroll">
          {lines.length === 0 ? (
            <div className="empty">
              <div className="empty-icon">🛍️</div>
              <p>Sua sacola está vazia.</p>
              <button className="btn-primary" onClick={onClose}>Ver cardápio</button>
            </div>
          ) : (
            <>
              <ul className="lines">
                {lines.map((l) => (
                  <li key={l.key} className="line">
                    <div className="line-img"><Img src={l.image} alt="" /></div>
                    <div className="line-info">
                      <strong>{l.name}</strong>
                      {l.note && <small>Obs: {l.note}</small>}
                      <span className="price sm">{money(l.price * l.qty)}</span>
                    </div>
                    <div className="stepper sm">
                      <button onClick={() => dispatch({ type: 'dec', key: l.key })} aria-label="Menos">−</button>
                      <span>{l.qty}</span>
                      <button onClick={() => dispatch({ type: 'inc', key: l.key })} aria-label="Mais">+</button>
                    </div>
                  </li>
                ))}
              </ul>

              {brand.freeDeliveryFrom > 0 && mode === 'delivery' && (
                <div className="free-bar">
                  {freeLeft > 0 ? (
                    <p>Faltam <b>{money(freeLeft)}</b> para <b>entrega grátis</b></p>
                  ) : (
                    <p>🎉 Você ganhou <b>entrega grátis</b>!</p>
                  )}
                  <div className="track"><div style={{ width: `${Math.min(100, (subtotal / brand.freeDeliveryFrom) * 100)}%` }} /></div>
                </div>
              )}

              {upsell.length > 0 && (
                <section className="upsell">
                  <h4>{brand.texts.upsellTitle}</h4>
                  <div className="upsell-row">
                    {upsell.map((i) => (
                      <button key={i.id} className="upsell-item" onClick={() => onAddItem(i)}>
                        <div className="u-img"><Img src={i.image} alt="" /></div>
                        <span className="u-name">{i.name}</span>
                        <span className="u-price">+ {money(i.price)}</span>
                      </button>
                    ))}
                  </div>
                </section>
              )}

              <section className="block">
                {brand.pickupEnabled && (
                  <div className="seg" role="tablist" aria-label="Tipo de pedido">
                    <button role="tab" aria-selected={mode === 'delivery'} className={mode === 'delivery' ? 'on' : ''} onClick={() => setMode('delivery')}>
                      🛵 Entrega
                    </button>
                    <button role="tab" aria-selected={mode === 'pickup'} className={mode === 'pickup' ? 'on' : ''} onClick={() => setMode('pickup')}>
                      🏪 Retirada
                    </button>
                  </div>
                )}

                <label className={`field ${errors.name ? 'has-error' : ''}`}>
                  <span>Seu nome</span>
                  <input ref={refs.name} autoComplete="name" value={customer.name} onChange={set('name')} placeholder="Como podemos te chamar?" />
                  {errors.name && <em>{errors.name}</em>}
                </label>
                <label className={`field ${errors.phone ? 'has-error' : ''}`}>
                  <span>WhatsApp</span>
                  <input ref={refs.phone} type="tel" inputMode="tel" autoComplete="tel" value={customer.phone} onChange={set('phone')} placeholder="(00) 00000-0000" />
                  {errors.phone && <em>{errors.phone}</em>}
                </label>
                {mode === 'delivery' && (
                  <>
                    <label className={`field ${errors.address ? 'has-error' : ''}`}>
                      <span>Endereço de entrega</span>
                      <input ref={refs.address} autoComplete="street-address" value={customer.address} onChange={set('address')} placeholder="Rua, número e bairro" />
                      {errors.address && <em>{errors.address}</em>}
                    </label>
                    <label className="field">
                      <span>Complemento <small>(opcional)</small></span>
                      <input value={customer.complement} onChange={set('complement')} placeholder="Apto, bloco, referência…" />
                    </label>
                  </>
                )}
              </section>

              <section className="block">
                <h4>Pagamento</h4>
                <div className="pay-row">
                  {brand.payments.map((p) => (
                    <button key={p.id} className={`pay ${paymentId === p.id ? 'on' : ''}`} onClick={() => setPaymentId(p.id)} aria-pressed={paymentId === p.id}>
                      <span className="pay-ico">{p.icon}</span>
                      <span>{p.label}</span>
                    </button>
                  ))}
                </div>
                <p className="pay-note">{payment.note}</p>
                {payment.id === 'cash' && (
                  <label className="field">
                    <span>Troco para quanto? <small>(opcional)</small></span>
                    <input inputMode="decimal" value={change} onChange={(e) => setChange(e.target.value)} placeholder="Ex.: R$ 100" />
                  </label>
                )}
                {payment.id === 'pix' && brand.pixKey && (
                  <button className="btn-link left" onClick={copyPix}>
                    {copied ? '✔ Chave copiada' : `Copiar chave Pix: ${brand.pixKey}`}
                  </button>
                )}
              </section>

              <section className="totals">
                <div><span>Subtotal</span><span>{money(subtotal)}</span></div>
                <div>
                  <span>{mode === 'delivery' ? 'Taxa de entrega' : 'Retirada'}</span>
                  <span>{fee === 0 ? 'Grátis' : money(fee)}</span>
                </div>
                <div className="grand"><span>Total</span><span>{money(total)}</span></div>
              </section>
            </>
          )}
        </div>

        {lines.length > 0 && (
          <div className="sheet-footer col">
            {belowMin && <p className="min-warn">Pedido mínimo de {money(brand.minOrder)} — faltam {money(brand.minOrder - subtotal)}.</p>}
            <button className="btn-primary wa" onClick={submit} disabled={belowMin}>
              {brand.texts.submit} · {money(total)}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
