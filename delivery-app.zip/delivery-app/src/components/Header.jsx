import { brand } from '../config'

export default function Header({ open }) {
  return (
    <header className="hero">
      <div
        className="hero-cover"
        style={brand.cover ? { backgroundImage: `url(${brand.cover})` } : undefined}
      />
      <div className="hero-card">
        <img className="logo" src={brand.logo} alt={`Logo ${brand.name}`} width="72" height="72" />
        <div className="hero-info">
          <h1>{brand.name}</h1>
          <p className="tagline">{brand.tagline}</p>
          <div className="chips">
            <span className={`chip ${open ? 'chip-ok' : 'chip-off'}`}>
              <i className="dot" /> {open ? 'Aberto agora' : 'Fechado'}
            </span>
            <span className="chip">🛵 {brand.deliveryTime}</span>
            {brand.minOrder > 0 && <span className="chip">Pedido mín. R$ {brand.minOrder.toFixed(0)}</span>}
          </div>
        </div>
      </div>
      {!open && brand.allowOrderWhenClosed && (
        <div className="closed-banner">
          Estamos fechados agora (abrimos às {brand.hours.open}). Você pode enviar seu pedido e confirmamos assim que abrir.
        </div>
      )}
    </header>
  )
}
