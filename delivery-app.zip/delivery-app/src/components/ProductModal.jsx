import { useEffect, useState } from 'react'
import { Img } from './ProductCard'
import { money } from '../utils'

export default function ProductModal({ item, onClose, onAdd }) {
  const [qty, setQty] = useState(1)
  const [note, setNote] = useState('')

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [onClose])

  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet" role="dialog" aria-modal="true" aria-label={item.name} onClick={(e) => e.stopPropagation()}>
        <button className="close" onClick={onClose} aria-label="Fechar">✕</button>
        <div className="sheet-img">
          <Img src={item.image} alt={item.name} />
        </div>
        <div className="sheet-body">
          <h2>{item.name}</h2>
          <p className="desc full">{item.description}</p>
          <div className="price-row">
            <strong className="price big">{money(item.price)}</strong>
            {item.oldPrice && <s className="old">{money(item.oldPrice)}</s>}
          </div>
          <label className="field">
            <span>Alguma observação?</span>
            <textarea
              rows="2"
              maxLength="140"
              placeholder="Ex.: sem cebola, ponto da carne, sabor…"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </label>
        </div>
        <div className="sheet-footer">
          <div className="stepper">
            <button onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Menos">−</button>
            <span>{qty}</span>
            <button onClick={() => setQty((q) => q + 1)} aria-label="Mais">+</button>
          </div>
          <button
            className="btn-primary grow"
            onClick={() => {
              onAdd(item, qty, note)
              onClose()
            }}
          >
            Adicionar · {money(item.price * qty)}
          </button>
        </div>
      </div>
    </div>
  )
}
