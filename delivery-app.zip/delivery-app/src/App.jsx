import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { brand } from './config'
import { categories } from './menu'
import { isOpenNow, money } from './utils'
import { useCart } from './useCart'
import Header from './components/Header'
import ProductCard from './components/ProductCard'
import ProductModal from './components/ProductModal'
import Bag from './components/Bag'

const norm = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()

export default function App() {
  const cart = useCart()
  const { dispatch, count, subtotal, qtyById } = cart
  const [query, setQuery] = useState('')
  const [active, setActive] = useState(categories[0].id)
  const [selected, setSelected] = useState(null)
  const [bagOpen, setBagOpen] = useState(false)
  const [toast, setToast] = useState('')
  const [open, setOpen] = useState(isOpenNow())
  const navRef = useRef(null)
  const lock = useRef(false)

  useEffect(() => {
    const t = setInterval(() => setOpen(isOpenNow()), 60000)
    return () => clearInterval(t)
  }, [])

  // trava o scroll do fundo quando há modal
  useEffect(() => {
    document.body.style.overflow = selected || bagOpen ? 'hidden' : ''
  }, [selected, bagOpen])

  const filtered = useMemo(() => {
    const q = norm(query.trim())
    if (!q) return categories
    return categories
      .map((c) => ({
        ...c,
        items: c.items.filter((i) => norm(`${i.name} ${i.description}`).includes(q)),
      }))
      .filter((c) => c.items.length)
  }, [query])

  // scrollspy: destaca a categoria visível
  useEffect(() => {
    if (query) return
    const els = categories.map((c) => document.getElementById(`cat-${c.id}`)).filter(Boolean)
    const io = new IntersectionObserver(
      (entries) => {
        if (lock.current) return
        const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)
        if (vis[0]) setActive(vis[0].target.id.replace('cat-', ''))
      },
      { rootMargin: '-120px 0px -65% 0px' },
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [query, filtered])

  // mantém a aba ativa visível na barra horizontal
  useEffect(() => {
    navRef.current?.querySelector('.on')?.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' })
  }, [active])

  const goTo = (id) => {
    setActive(id)
    lock.current = true
    document.getElementById(`cat-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    setTimeout(() => (lock.current = false), 700)
  }

  const flash = useCallback((msg) => {
    setToast(msg)
    clearTimeout(flash.t)
    flash.t = setTimeout(() => setToast(''), 1400)
  }, [])

  const add = useCallback(
    (item, qty = 1, note = '') => {
      dispatch({ type: 'add', item, qty, note })
      flash(`${item.name} adicionado`)
      navigator.vibrate?.(10)
    },
    [dispatch, flash],
  )
  const remove = useCallback((id) => dispatch({ type: 'decById', id }), [dispatch])
  const openItem = useCallback((item) => setSelected(item), [])

  return (
    <div className="app">
      <Header open={open} />

      <div className="sticky">
        <div className="search">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>
          <input
            type="search"
            placeholder={brand.texts.searchPlaceholder}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="Buscar no cardápio"
          />
        </div>
        {!query && (
          <nav className="cats" ref={navRef} aria-label="Categorias">
            {categories.map((c) => (
              <button key={c.id} className={active === c.id ? 'on' : ''} onClick={() => goTo(c.id)}>
                <span>{c.emoji}</span> {c.name}
              </button>
            ))}
          </nav>
        )}
      </div>

      <main className="menu">
        {filtered.length === 0 && <p className="no-results">Nada encontrado para “{query}”.</p>}
        {filtered.map((c) => (
          <section key={c.id} id={`cat-${c.id}`} className="cat">
            <h2>{c.emoji} {c.name}</h2>
            <div className="grid">
              {c.items.map((item) => (
                <ProductCard
                  key={item.id}
                  item={item}
                  qty={qtyById[item.id] || 0}
                  onAdd={add}
                  onRemove={remove}
                  onOpen={openItem}
                />
              ))}
            </div>
          </section>
        ))}
        <footer className="foot">
          <p>{brand.name} · Horário: {brand.hours.open} às {brand.hours.close}</p>
        </footer>
      </main>

      {count > 0 && !bagOpen && (
        <div className="bag-bar">
          <button onClick={() => setBagOpen(true)} aria-label="Abrir sacola">
            <span className="bag-count">{count}</span>
            <span className="bag-label">Ver sacola</span>
            <span className="bag-total">{money(subtotal)}</span>
          </button>
        </div>
      )}

      {toast && <div className="toast" role="status">✓ {toast}</div>}

      {selected && <ProductModal item={selected} onClose={() => setSelected(null)} onAdd={add} />}
      {bagOpen && <Bag cart={cart} onClose={() => setBagOpen(false)} onAddItem={(i) => add(i)} />}
    </div>
  )
}
