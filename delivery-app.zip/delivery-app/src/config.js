// ============================================================
//  PERSONALIZAÇÃO DA MARCA — edite apenas este arquivo (e menu.js)
//  para adaptar o app a qualquer delivery.
// ============================================================

export const brand = {
  name: 'Burger House',
  tagline: 'Hambúrguer artesanal · Entrega rápida',
  logo: '/logo.svg', // troque por /sua-logo.png (coloque o arquivo na pasta public/)
  cover:
    'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1200&q=70', // deixe '' para usar só a cor
  colors: {
    primary: '#d62828', // botões, preços, destaques
    primaryDark: '#a81d1d',
    accent: '#ffb703', // selos e detalhes
    background: '#f7f5f2',
    text: '#1f1f1f',
  },

  // WhatsApp que recebe os pedidos (DDI + DDD + número, só dígitos)
  whatsapp: '5511999999999',

  // Entrega
  deliveryFee: 6.0,
  freeDeliveryFrom: 70.0, // 0 desativa a barra de frete grátis
  minOrder: 25.0, // 0 desativa
  pickupEnabled: true,
  deliveryTime: '35–50 min',
  pickupTime: '15–25 min',

  // Horário de funcionamento (24h). Use days: [0..6], 0 = domingo
  hours: { open: '18:00', close: '23:30', days: [0, 1, 2, 3, 4, 5, 6] },
  allowOrderWhenClosed: true, // true = permite agendar/pedir mesmo fechado (mostra aviso)

  // Formas de pagamento
  payments: [
    { id: 'pix', label: 'Pix', icon: '⚡', note: 'Pague na entrega ou envie o comprovante' },
    { id: 'card', label: 'Cartão', icon: '💳', note: 'Débito ou crédito na entrega' },
    { id: 'cash', label: 'Dinheiro', icon: '💵', note: 'Informe se precisa de troco' },
  ],
  pixKey: '', // opcional: chave Pix para exibir botão "Copiar chave"

  currency: 'BRL',
  locale: 'pt-BR',

  // Textos
  texts: {
    searchPlaceholder: 'Buscar no cardápio…',
    submit: 'Enviar pedido no WhatsApp',
    upsellTitle: 'Peça também',
  },
}
