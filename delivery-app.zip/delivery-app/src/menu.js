// Cardápio: categorias → itens.
// Campos do item: id (único), name, description, price, image (URL ou /arquivo.jpg na pasta public),
// badge (opcional: "Mais pedido", "Novo"...), popular (true = aparece como sugestão na sacola),
// oldPrice (opcional, mostra preço "de/por").

const img = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=600&q=70`

export const categories = [
  {
    id: 'burgers',
    name: 'Hambúrgueres',
    emoji: '🍔',
    items: [
      {
        id: 'b1',
        name: 'Classic Burger',
        description: 'Pão brioche, blend 160g, queijo cheddar, alface, tomate e molho da casa.',
        price: 29.9,
        image: img('photo-1568901346375-23c9450c58cd'),
        badge: 'Mais pedido',
        popular: true,
      },
      {
        id: 'b2',
        name: 'Bacon Duplo',
        description: 'Dois blends de 120g, muito bacon crocante, cheddar duplo e cebola caramelizada.',
        price: 38.9,
        oldPrice: 42.9,
        image: img('photo-1553979459-d2229ba7433b'),
        popular: true,
      },
      {
        id: 'b3',
        name: 'Smash Salad',
        description: 'Smash 90g, queijo prato, picles, cebola roxa e maionese defumada.',
        price: 27.9,
        image: img('photo-1550547660-d9450f859349'),
      },
      {
        id: 'b4',
        name: 'Frango Crocante',
        description: 'Filé de frango empanado, queijo, alface americana e molho honey mustard.',
        price: 31.9,
        image: img('photo-1606755962773-d324e0a13086'),
        badge: 'Novo',
      },
    ],
  },
  {
    id: 'combos',
    name: 'Combos',
    emoji: '🍟',
    items: [
      {
        id: 'c1',
        name: 'Combo Classic',
        description: 'Classic Burger + batata média + refrigerante lata 350ml.',
        price: 44.9,
        oldPrice: 51.7,
        image: img('photo-1594212699903-ec8a3eca50f5'),
        badge: 'Economize',
        popular: true,
      },
      {
        id: 'c2',
        name: 'Combo Bacon Duplo',
        description: 'Bacon Duplo + batata grande + refrigerante lata 350ml.',
        price: 56.9,
        image: img('photo-1572802419224-296b0aeee0d9'),
      },
    ],
  },
  {
    id: 'porcoes',
    name: 'Porções',
    emoji: '🧆',
    items: [
      {
        id: 'p1',
        name: 'Batata Frita',
        description: 'Porção crocante com sal e ervas. Serve 1 a 2 pessoas.',
        price: 18.9,
        image: img('photo-1573080496219-bb080dd4f877'),
        popular: true,
      },
      {
        id: 'p2',
        name: 'Onion Rings',
        description: 'Anéis de cebola empanados com molho barbecue.',
        price: 21.9,
        image: img('photo-1639024471283-03518883512d'),
      },
      {
        id: 'p3',
        name: 'Nuggets (10un)',
        description: 'Nuggets de frango com molho à escolha.',
        price: 22.9,
        image: img('photo-1562967914-608f82629710'),
      },
    ],
  },
  {
    id: 'bebidas',
    name: 'Bebidas',
    emoji: '🥤',
    items: [
      {
        id: 'd1',
        name: 'Refrigerante Lata',
        description: 'Coca-Cola, Guaraná ou Sprite 350ml. Informe o sabor na observação.',
        price: 6.5,
        image: img('photo-1629203851122-3726ecdf080e'),
        popular: true,
      },
      {
        id: 'd2',
        name: 'Suco Natural 400ml',
        description: 'Laranja, limão ou maracujá. Informe o sabor na observação.',
        price: 9.9,
        image: img('photo-1600271886742-f049cd451bba'),
      },
      {
        id: 'd3',
        name: 'Milkshake 400ml',
        description: 'Chocolate, morango ou ovomaltine.',
        price: 17.9,
        image: img('photo-1572490122747-3968b75cc699'),
      },
    ],
  },
  {
    id: 'sobremesas',
    name: 'Sobremesas',
    emoji: '🍰',
    items: [
      {
        id: 's1',
        name: 'Brownie com Sorvete',
        description: 'Brownie quentinho com bola de sorvete de creme e calda de chocolate.',
        price: 19.9,
        image: img('photo-1564355808539-22fda35bed7e'),
        badge: 'Favorito',
      },
    ],
  },
]
