import { brand } from './config'

const fmt = new Intl.NumberFormat(brand.locale, { style: 'currency', currency: brand.currency })
export const money = (v) => fmt.format(v)

const toMin = (hhmm) => {
  const [h, m] = hhmm.split(':').map(Number)
  return h * 60 + m
}

export function isOpenNow(now = new Date()) {
  const { open, close, days } = brand.hours
  const cur = now.getHours() * 60 + now.getMinutes()
  const o = toMin(open)
  const c = toMin(close)
  const day = now.getDay()
  if (o <= c) return days.includes(day) && cur >= o && cur < c
  // vira a meia-noite
  if (cur >= o) return days.includes(day)
  return days.includes((day + 6) % 7) && cur < c
}

export const onlyDigits = (s) => s.replace(/\D/g, '')

export function maskPhone(v) {
  const d = onlyDigits(v).slice(0, 11)
  if (d.length <= 2) return d
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`
}

export const load = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : fallback
  } catch {
    return fallback
  }
}
export const save = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* ignore */
  }
}

export function buildWhatsAppUrl({ lines, mode, customer, payment, change, subtotal, fee, total }) {
  const items = lines
    .map(
      (l) =>
        `• ${l.qty}x ${l.name} — ${money(l.price * l.qty)}${l.note ? `\n   _Obs: ${l.note}_` : ''}`,
    )
    .join('\n')

  const parts = [
    `*Novo pedido — ${brand.name}*`,
    '',
    items,
    '',
    `Subtotal: ${money(subtotal)}`,
    mode === 'delivery' ? `Entrega: ${fee === 0 ? 'Grátis' : money(fee)}` : 'Retirada no local',
    `*Total: ${money(total)}*`,
    '',
    `*Pagamento:* ${payment.label}${
      payment.id === 'cash' ? (change ? ` (troco para ${change})` : ' (sem troco)') : ''
    }`,
    '',
    `*Cliente:* ${customer.name}`,
    `*Telefone:* ${customer.phone}`,
  ]
  if (mode === 'delivery') {
    parts.push(`*Endereço:* ${customer.address}`)
    if (customer.complement) parts.push(`*Complemento:* ${customer.complement}`)
  }
  return `https://wa.me/${brand.whatsapp}?text=${encodeURIComponent(parts.join('\n'))}`
}
