import { useEffect, useMemo, useReducer } from 'react'
import { load, save } from './utils'

const KEY = 'delivery:cart:v1'

function reducer(state, a) {
  switch (a.type) {
    case 'add': {
      const note = (a.note || '').trim()
      const key = `${a.item.id}|${note}`
      const qty = a.qty || 1
      const found = state.find((l) => l.key === key)
      if (found) return state.map((l) => (l.key === key ? { ...l, qty: l.qty + qty } : l))
      return [
        ...state,
        { key, id: a.item.id, name: a.item.name, price: a.item.price, image: a.item.image, note, qty },
      ]
    }
    case 'inc':
      return state.map((l) => (l.key === a.key ? { ...l, qty: l.qty + 1 } : l))
    case 'dec':
      return state.flatMap((l) => (l.key !== a.key ? [l] : l.qty > 1 ? [{ ...l, qty: l.qty - 1 }] : []))
    case 'decById': {
      const idx = [...state].reverse().findIndex((l) => l.id === a.id)
      if (idx === -1) return state
      const real = state.length - 1 - idx
      return state.flatMap((l, i) => (i !== real ? [l] : l.qty > 1 ? [{ ...l, qty: l.qty - 1 }] : []))
    }
    case 'clear':
      return []
    default:
      return state
  }
}

export function useCart() {
  const [lines, dispatch] = useReducer(reducer, null, () => load(KEY, []))
  useEffect(() => save(KEY, lines), [lines])

  const { count, subtotal, qtyById } = useMemo(() => {
    const qtyById = {}
    let count = 0
    let subtotal = 0
    for (const l of lines) {
      count += l.qty
      subtotal += l.qty * l.price
      qtyById[l.id] = (qtyById[l.id] || 0) + l.qty
    }
    return { count, subtotal, qtyById }
  }, [lines])

  return { lines, dispatch, count, subtotal, qtyById }
}
