import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import { brand } from './config'
import './styles.css'

// Aplica as cores e o título da marca
const r = document.documentElement.style
r.setProperty('--primary', brand.colors.primary)
r.setProperty('--primary-dark', brand.colors.primaryDark)
r.setProperty('--accent', brand.colors.accent)
r.setProperty('--bg', brand.colors.background)
r.setProperty('--text', brand.colors.text)
document.title = `${brand.name} · Cardápio`
document.querySelector('meta[name="theme-color"]')?.setAttribute('content', brand.colors.primary)

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
