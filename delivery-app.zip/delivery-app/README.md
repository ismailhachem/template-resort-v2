# Delivery App (React + Vite)

Cardápio digital + sacola, com envio do pedido pelo WhatsApp. Pensado para converter com poucos cliques.

## Rodar

```bash
npm install
npm run dev      # desenvolvimento
npm run build    # gera a pasta dist/ (publique em Netlify, Vercel, Cloudflare Pages, etc.)
```

## Personalizar para cada marca

| O que mudar | Onde |
|---|---|
| Nome, logo, capa, cores, WhatsApp, taxa de entrega, frete grátis, pedido mínimo, horário, pagamentos, chave Pix | `src/config.js` |
| Categorias, produtos, preços, fotos, selos | `src/menu.js` |
| Logo (arquivo) | coloque em `public/` e aponte em `brand.logo` |

## Fluxo de pedido (cliques)

1. Toca em **+** no produto (1 clique por item)
2. Toca em **Ver sacola**
3. Dados já vêm preenchidos para clientes recorrentes (salvos no aparelho)
4. Toca em **Enviar pedido no WhatsApp**

## Observações

- A sacola e os dados do cliente ficam salvos no navegador (localStorage).
- As fotos de exemplo vêm do Unsplash; troque pelas fotos reais do cliente em `src/menu.js`.
- O pedido é enviado como mensagem formatada para o WhatsApp da loja. Para integrar com um sistema de pedidos/PDV, substitua `buildWhatsAppUrl` / `submit` em `src/components/Bag.jsx` por uma chamada à sua API.
